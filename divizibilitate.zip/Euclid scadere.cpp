#include <iostream>
using namespace std;

int main()
{
    int n , m;
    cin >> n >> m;
    while(n != m) //algoritmul se aplica atat timp cat numerele sunt diferite
        if(n> m) //determinarea numarului mai mare si scaderea acestuia cu cel mai mic
            n = n - m;
        else
            m = m - n;
    cout << n << endl; //atunci cand numerele devin egale, se afiseaza unul din numere (acesta are valoare ccmmdc al numerelor initiale)
    return 0;
}
