#include <iostream>

using namespace std;
int f(int a, int b, int d)
{
    int cnt = 0;
    for (int i = a; i <= b; i++) //for-ul care determina intervalul
        if (i % d == 0) //verificam daca numarul din interval e divizibil cu d
            cnt++;
    return cnt;
}

int main()
{
    int a, b, d;
    cin >> a >> b >> d;
    cout << f(a, b, d);
    return 0;
}
