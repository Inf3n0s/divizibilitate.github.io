/*Verificați dacă toate prefixele unui număr
sunt divizibile cu numărul de cifre rămas*/

#include <iostream>
using namespace std;

int prf(int n)
{
    int i = 1;

    while (n > 0) {

        // Verificare divizibilitate
        if (n % i != 0)
            return 0;

        // Actualizarea numărului
        n = n / 10;
        i++;
    }

    return 1;
}

int main()
{
    int n;
    cin>>n;
    if (prf(n))
        cout << "DA" << endl;
    else
        cout << "NU" << endl;

    return 0;
}
