//Numarul minim de numere divizibile cu n formate folosind doar cifra c
#include <iostream>
using namespace std;

int f(int n, int c)
{
    int cnt = 1;
    int m = c % n;

    // Vector auxiliar pentru resturile deja gasite
    int v[101];
    v[m] = 1;

    while (v[m]==1)
    {
        if (m == 0)
            return cnt;
        m = (((m * (10 % n)) % n) + (c % n)) % n;

        // In caz ca restul a mai fost gasit, afisam -1
        if (v[m] == 1)
            return -1;
        v[m] = 1;
        cnt++;
    }
    return -1;
}

int main()
{
    int n, c;
    cin>>n>>c;
    cout<<f(n, c);
    return 0;
}
