#include <iostream>
using namespace std;

int f(int v[], int n, int d)
{
    int i, j, cnt = 0;

    // numaram perechile
    for (i = 1; i <= n; i++) {
        for (j = i + 1; j <= n; j++) {
            if ((v[i] - v[j] + d) % d == 0)
                cnt += 1;
        }
    }
    return cnt;
}

int main()
{
    int v[101], n, d;
    cin >> n >> d;
    for (int i = 1; i <=n; i++)
        cin >> v[i];
    cout << f(v, n, d);
    return 0;
}
