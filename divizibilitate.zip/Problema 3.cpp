//Verificare daca un numar mare este divizibil cu 13
#include <iostream>
#include <string.h>
#include <cmath>
using namespace std;

int d(char nr[])
{
    int n = strlen(nr);
    if (n == 1 && nr[0] == '0')
        return 1;

    // Adaugarea 0-urilor necesare la inceput
    if (n % 3 == 1)
    {
        strcat(nr,"00");
        n += 2;
    }
    else if (n % 3 == 2)
    {
        strcat(nr,"0");
        n += 1;
    }

    // Adaugam sau scadem cifre in grupe de trei
    int s = 0, p = 1;
    for (int i = n - 1; i >= 0; i--)
    {
        // Memoram grupe de 3 numere in variabila g
        int g = 0;
        g += nr[i--] - '0';
        g += (nr[i--] - '0') * 10;
        g += (nr[i] - '0') * 100;

        s = s + g * p;

        // Generam seria de semne alternative
        p *= (-1);
    }
    s = abs(s);
    return (s % 13 == 0);
}

int main()
{
    char nr[256];
    cin.getline(nr, 256);
    if (d(nr))
        cout <<"DA";
    else
        cout <<"NU";
    return 0;
}
