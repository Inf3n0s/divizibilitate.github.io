#include <iostream>
using namespace std;

int main()
{
    int n , m;
    in >> n >> m;
    while(m != 0) //m diferit de 0, altfel impartirea nu putea fi realizata
    {
        int r = n % m; //retsul impartirii numerelor + interschimbare
        n = m;
        m = r;
    }
    cout << n << endl; //n va avea valoarea cmmdc
    return 0;
}
