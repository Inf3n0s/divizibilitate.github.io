//Cel mai mic sir divizibil cu 2 siruri
#include <iostream>
#include <string.h>
using namespace std;

int cmmdc(int a, int b)
{
    if (b == 0)
        return a;
    return cmmdc(b, a % b);
}

int cmmmc(int a, int b)
{
    return (a / cmmdc(a, b)) * b;
}

// Cel mai mic șir divizibil cu ambele șiruri
void st(char s[], char t[])
{
    // Calculam lungimile sirurilor
    int n = strlen(s), m = strlen(t);

    // Cmmmc al lungimilor celor 2 siruri
    int l = cmmmc(n, m);

    // Initializam siruri auxiliare, cu care vom
    //memora sirurile concatenate
    char s1[256], t1[256];
    strcpy(s1,"");
    strcpy(t1,"");

    // Concatenarea lui s1 de (l / n) ori
    for (int i = 0; i < l / n; i++)
    {
        strcat(s1,s);
    }

    // Concatenarea lui t1 de (l / m) ori
    for (int i = 0; i < l / m; i++)
    {
        strcat(t1,t);
    }

    if (strcmp(s1,t1)==0)
        cout << s1;
    else
        cout << -1;
}

int main()
{
    char s[256], t[256];
    cin.getline(s,256);
    cin.get(t,256);
    st(s, t);
    return 0;
}
