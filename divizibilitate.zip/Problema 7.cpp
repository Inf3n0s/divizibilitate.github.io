#include <iostream>
using namespace std;

int f(int n)
{
    int cn = 0, cnt = 0;

    // Factorii primi = 2
    while (n % 2 == 0)
    {
        n /= 2;
        cn++;
    }

    // Factorii primi = 5
    while (n % 5 == 0)
    {
        n /= 5;
        cnt++;
    }
    if (n == 1 && cn <= cnt)
    {
        // Numarul minim de operatii
        return 2 * cnt - cn;
    }

    // In caz ca n nu poate fi redus
    else
        return -1;
}
int main()
{
    int n;
    cin>>n;
    cout << f(n);
    return 0;
}
